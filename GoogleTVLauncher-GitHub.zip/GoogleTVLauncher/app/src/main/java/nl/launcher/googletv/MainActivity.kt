package nl.launcher.googletv

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var search: EditText
    private lateinit var clock: TextView
    private lateinit var weather: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var allApps: List<ResolveInfo> = emptyList()
    private var showingFavorites = false
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val favoriteSet get() = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()

    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("EEEE d MMMM  •  HH:mm", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        buildShell()
        loadApps()
        refreshWeather()
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(22), dp(42), dp(22))
            setBackgroundColor(0xFF101318.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "◉  TV"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
        }
        clock = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFCFD5DF.toInt())
            gravity = Gravity.CENTER
        }
        weather = TextView(this).apply {
            text = "Weer • stel plaats in"
            textSize = 14f
            setTextColor(0xFFCFD5DF.toInt())
            gravity = Gravity.CENTER
            setOnClickListener { askCity() }
            isFocusable = true
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(weather, LinearLayout.LayoutParams(dp(210), dp(48)))
        header.addView(clock, LinearLayout.LayoutParams(dp(270), dp(48)))
        root.addView(header)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(16))
        }
        search = EditText(this).apply {
            hint = "Zoek een app..."
            textSize = 17f
            singleLine = true
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA4B2.toInt())
            setPadding(dp(16), 0, dp(16), 0)
            setBackgroundColor(0xFF252B35.toInt())
            isFocusable = true
            addTextChangedListener(SimpleWatcher { renderApps() })
        }
        controls.addView(search, LinearLayout.LayoutParams(dp(360), dp(48)))
        controls.addView(actionButton("Alle apps") { showingFavorites = false; renderApps() })
        controls.addView(actionButton("Favorieten") { showingFavorites = true; renderApps() })
        controls.addView(actionButton("Achtergrond") { chooseBackground() })
        controls.addView(actionButton("Instellingen") { showSettings() })
        root.addView(controls)

        val title = TextView(this).apply {
            text = "Jouw apps"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(title)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isFocusable = true
            setOnClickListener { action() }
        }

    private fun loadApps() {
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        )
        val found = LinkedHashMap<String, ResolveInfo>()
        intents.forEach { intent ->
            packageManager.queryIntentActivities(intent, 0).forEach {
                val key = it.activityInfo.packageName
                if (key != packageName) found[key] = it
            }
        }
        allApps = found.values.sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        renderApps()
    }

    private fun renderApps() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        val query = if (::search.isInitialized) search.text.toString().trim().lowercase() else ""
        val favorites = favoriteSet
        val filtered = allApps.filter {
            val name = it.loadLabel(packageManager).toString()
            (query.isEmpty() || name.lowercase().contains(query)) &&
                (!showingFavorites || favorites.contains(it.activityInfo.packageName))
        }
        if (filtered.isEmpty()) {
            content.addView(TextView(this).apply {
                text = if (showingFavorites) "Nog geen favorieten. Houd een app ingedrukt om deze toe te voegen."
                       else "Geen apps gevonden."
                textSize = 16f
                setTextColor(0xFFCFD5DF.toInt())
                setPadding(0, dp(20), 0, dp(20))
            })
            return
        }
        var row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        filtered.forEachIndexed { index, info ->
            if (index > 0 && index % 5 == 0) {
                content.addView(row)
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            }
            addAppTile(row, info, favorites)
        }
        content.addView(row)
    }

    private fun addAppTile(row: LinearLayout, info: ResolveInfo, favorites: MutableSet<String>) {
        val pkg = info.activityInfo.packageName
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(10))
            setBackgroundColor(0xFF202630.toInt())
            isFocusable = true
            isFocusableInTouchMode = true
            contentDescription = info.loadLabel(packageManager)
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                    ?: Intent(Intent.ACTION_MAIN).setClassName(pkg, info.activityInfo.name)
                try { startActivity(launch) } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "App kan niet worden gestart", Toast.LENGTH_SHORT).show()
                }
            }
            setOnLongClickListener {
                val updated = favoriteSet
                if (updated.contains(pkg)) updated.remove(pkg) else updated.add(pkg)
                prefs.edit().putStringSet("favorites", updated).apply()
                Toast.makeText(this@MainActivity,
                    if (updated.contains(pkg)) "Toegevoegd aan favorieten" else "Verwijderd uit favorieten",
                    Toast.LENGTH_SHORT).show()
                renderApps()
                true
            }
        }
        val icon = ImageView(this).apply {
            setImageDrawable(info.loadIcon(packageManager))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        tile.addView(icon, LinearLayout.LayoutParams(dp(62), dp(62)))
        tile.addView(TextView(this).apply {
            text = info.loadLabel(packageManager)
            textSize = 12f
            gravity = Gravity.CENTER
            maxLines = 2
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(7), 0, 0)
        }, LinearLayout.LayoutParams(-1, dp(38)))
        row.addView(tile, LinearLayout.LayoutParams(dp(145), dp(142)).apply {
            setMargins(dp(5), dp(5), dp(9), dp(12))
        })
    }

    private fun askCity() {
        val input = EditText(this).apply { hint = "Bijv. Amsterdam"; setText(prefs.getString("city", "")) }
        AlertDialog.Builder(this).setTitle("Weerlocatie")
            .setMessage("Vul een plaatsnaam in voor het actuele weer.")
            .setView(input)
            .setPositiveButton("Opslaan") { _, _ ->
                prefs.edit().putString("city", input.text.toString().trim()).apply()
                refreshWeather()
            }.setNegativeButton("Annuleren", null).show()
    }

    private fun refreshWeather() {
        val city = prefs.getString("city", "") ?: ""
        if (city.isBlank()) { weather.text = "Weer • plaats instellen"; return }
        weather.text = "Weer ophalen…"
        thread {
            try {
                val encoded = URLEncoder.encode(city, "UTF-8")
                val geo = JSONObject(URL("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=nl&format=json").readText())
                val place = geo.optJSONArray("results")?.optJSONObject(0)
                    ?: throw Exception("Plaats niet gevonden")
                val lat = place.getDouble("latitude")
                val lon = place.getDouble("longitude")
                val data = JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto").readText())
                val current = data.getJSONObject("current")
                val temp = current.getDouble("temperature_2m").toInt()
                val label = place.optString("name", city)
                runOnUiThread { weather.text = "$label  •  ${temp}°C" }
            } catch (_: Exception) {
                runOnUiThread { weather.text = "Weer niet beschikbaar" }
            }
        }
    }

    private fun chooseBackground() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(intent, 41) }
        catch (_: Exception) { Toast.makeText(this, "Afbeelding kiezen niet beschikbaar", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Legacy result callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    prefs.edit().putString("background_uri", uri.toString()).apply()
                    applyBackground(uri)
                } catch (_: Exception) {}
            }
        }
    }

    private fun applyBackground(uri: Uri) {
        try {
            val stream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(stream)
            stream?.close()
            if (bitmap != null) root.background = android.graphics.drawable.BitmapDrawable(resources, bitmap)
        } catch (_: Exception) {
            Toast.makeText(this, "Achtergrond kon niet worden geladen", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSettings() {
        val options = arrayOf("Weerlocatie instellen", "Achtergrond kiezen", "Favorieten wissen", "Launcher opnieuw laden")
        AlertDialog.Builder(this).setTitle("Instellingen").setItems(options) { _, which ->
            when (which) {
                0 -> askCity()
                1 -> chooseBackground()
                2 -> { prefs.edit().remove("favorites").apply(); renderApps() }
                3 -> loadApps()
            }
        }.show()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) {
            prefs.getString("background_uri", null)?.let { applyBackground(Uri.parse(it)) }
            loadApps()
        }
    }
}

private class SimpleWatcher(val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
