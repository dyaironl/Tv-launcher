plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "nl.launcher.googletv"
    compileSdk = 35
    defaultConfig {
        applicationId = "nl.launcher.googletv"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
