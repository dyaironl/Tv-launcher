# TV Launcher (Android TV / Google TV)

Een startproject voor een eigen Android TV-home launcher, met appbibliotheek, zoeken,
favorieten, klok/datum, weer via Open-Meteo, achtergrondkeuze en instellingen.

## Bouwen
1. Installeer Android Studio (Hedgehog of nieuwer) en Android SDK 35.
2. Open deze map als Gradle-project.
3. Laat Gradle synchroniseren en bouw via **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Installeer de APK op je Android TV/Google TV (bijvoorbeeld via ADB of USB).

## Als standaard startscherm instellen
Na installatie druk je op de Home-knop. Kies **TV Launcher** en selecteer **Altijd**
als Android die keuze aanbiedt. Dit hangt af van de fabrikant en firmware.

## Bediening
- D-pad: navigeren tussen knoppen en apps; OK opent een app.
- Lang indrukken op een app: favoriet aan/uit.
- Zoekveld: filtert de appbibliotheek.
- Weer: selecteer bovenaan de weertekst om een plaats in te stellen.
- Achtergrond: kies een afbeelding op het apparaat.

## Belangrijke opmerkingen
- De app vraagt `QUERY_ALL_PACKAGES` om geïnstalleerde apps te kunnen tonen.
  Google Play beperkt het gebruik hiervan; distributie buiten Play kan eenvoudiger zijn.
- Sommige tv-fabrikanten beperken het vervangen van het standaard startscherm.
- De zoekfunctie filtert momenteel geïnstalleerde apps; dit is geen universele
  spraakassistent of zoekmachine voor streamingcatalogi.
- Dit is broncode voor een bouwbare eerste versie. De APK moet in Android Studio
  op een computer worden gebouwd en op het tv-apparaat worden getest.


## APK bouwen via GitHub (zonder Android Studio)

1. Maak een repository aan op https://github.com (bijvoorbeeld `tv-launcher`).
2. Pak `GoogleTVLauncher-project.zip` uit op je apparaat.
3. Upload alle bestanden en mappen uit de uitgepakte projectmap naar de repository. Zorg dat ook de verborgen map `.github` wordt geüpload.
4. Open in GitHub het tabblad **Actions**.
5. Kies **Build Android TV Launcher APK** en druk op **Run workflow** (of wacht tot de automatische build na een push klaar is).
6. Open de geslaagde workflow-run. Onder **Artifacts** download je `TV-Launcher-debug-APK`.
7. Pak het artifact-ZIP-bestand uit. Daarin staat `app-debug.apk`.

De GitHub Actions-workflow bouwt een debug-APK. Dit is geschikt om zelf te testen en is niet ondertekend als release-app voor publicatie in Google Play.
